<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Handle property listing
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['edit_property_id'])) {
    try {
        $user_id = $_SESSION['user_id'];
        $property_type = $_POST['property_type'];
        $property_size = $_POST['property_size'];
        $size_unit = $_POST['size_unit'];
        $ownership_status = $_POST['ownership_status'];
        $features = $_POST['features'];
        $description = $_POST['description'];
        $estimated_price_per_unit = $_POST['estimated_price_per_unit'];
        $total_value = $_POST['total_value'];
        $future_value = $_POST['future_value'] ?: null;
        $seller_type = $_POST['seller_type'];
        $negotiation = isset($_POST['negotiation']) ? 1 : 0;
        $brokering = isset($_POST['brokering']) ? 1 : 0;
        $location = $_POST['location'];
        $city = $_POST['city'];
        $usage_type = $_POST['usage_type'];
        $image_url = $_POST['image_url'] ?? null;

        $sql = "INSERT INTO properties (user_id, property_type, property_size, size_unit, ownership_status, features, description, estimated_price_per_unit, total_value, future_value, seller_type, negotiation, brokering, location, city, usage_type, image_url) 
                VALUES (:user_id, :property_type, :property_size, :size_unit, :ownership_status, :features, :description, :estimated_price_per_unit, :total_value, :future_value, :seller_type, :negotiation, :brokering, :location, :city, :usage_type, :image_url)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':user_id' => $user_id,
            ':property_type' => $property_type,
            ':property_size' => $property_size,
            ':size_unit' => $size_unit,
            ':ownership_status' => $ownership_status,
            ':features' => $features,
            ':description' => $description,
            ':estimated_price_per_unit' => $estimated_price_per_unit,
            ':total_value' => $total_value,
            ':future_value' => $future_value,
            ':seller_type' => $seller_type,
            ':negotiation' => $negotiation,
            ':brokering' => $brokering,
            ':location' => $location,
            ':city' => $city,
            ':usage_type' => $usage_type,
            ':image_url' => $image_url
        ]);
        $success = "Property listed successfully!";
    } catch (PDOException $e) {
        $error = "Error listing property: " . $e->getMessage();
    }
}

// Handle property deletion
if (isset($_GET['delete_id'])) {
    try {
        $property_id = $_GET['delete_id'];
        $sql = "DELETE FROM properties WHERE property_id = :property_id AND user_id = :user_id AND status = 'available'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':property_id' => $property_id, ':user_id' => $_SESSION['user_id']]);
        $success = "Property deleted successfully!";
    } catch (PDOException $e) {
        $error = "Error deleting property: " . $e->getMessage();
    }
}

// Fetch user's listed properties
$sql = "SELECT * FROM properties WHERE user_id = :user_id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':user_id' => $_SESSION['user_id']]);
$listed_properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch pending buyer requests
$sql = "SELECT t.transaction_id, t.property_id, t.buyer_id, t.transaction_type, p.property_type, p.property_size, p.size_unit, p.location, p.city, p.total_value, u.username AS buyer_username, u.contact_info AS buyer_contact 
        FROM transactions t 
        JOIN properties p ON t.property_id = p.property_id 
        JOIN users u ON t.buyer_id = u.user_id 
        WHERE p.user_id = :user_id AND t.status = 'pending'";
$stmt = $pdo->prepare($sql);
$stmt->execute([':user_id' => $_SESSION['user_id']]);
$pending_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch chat conversations for seller's properties
$sql = "SELECT DISTINCT m.property_id, p.property_type, p.city, u.username AS buyer_username, 
        MAX(m.sent_at) AS last_message 
        FROM messages m 
        JOIN properties p ON m.property_id = p.property_id 
        JOIN users u ON m.sender_id = u.user_id 
        WHERE p.user_id = :user_id 
        GROUP BY m.property_id, p.property_type, p.city, u.username";
$stmt = $pdo->prepare($sql);
$stmt->execute([':user_id' => $_SESSION['user_id']]);
$conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>REMA - Seller Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3f37c9;
            --primary-dark: #372fb5;
            --secondary: #4361ee;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
            --info: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fb;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .dashboard-header h1 {
            color: var(--primary);
            font-weight: 600;
            font-size: 28px;
            margin: 0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .nav-header {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            overflow: hidden;
        }
        
        .nav-menu {
            display: flex;
            list-style: none;
        }
        
        .nav-menu li {
            flex: 1;
        }
        
        .nav-menu a {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 15px 10px;
            color: var(--gray);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .nav-menu a:hover, .nav-menu a.active {
            background-color: rgba(63, 55, 201, 0.1);
            color: var(--primary);
        }
        
        .nav-menu i {
            font-size: 18px;
            margin-bottom: 5px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--dark);
            margin: 0;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 14px;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .btn-success {
            background-color: var(--success);
            color: white;
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 13px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--light-gray);
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(63, 55, 201, 0.2);
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .table th {
            background-color: var(--primary);
            color: white;
            padding: 12px 15px;
            text-align: left;
            font-weight: 500;
        }
        
        .table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--light-gray);
            vertical-align: middle;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        .table tr:hover {
            background-color: rgba(63, 55, 201, 0.05);
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
        }
        
        .badge-warning {
            background-color: rgba(248, 150, 30, 0.1);
            color: var(--warning);
        }
        
        .badge-danger {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
        }
        
        .alert {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }
        
        .alert-danger {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }
        
        .grid {
            display: grid;
            gap: 20px;
        }
        
        .grid-cols-2 {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .grid-cols-3 {
            grid-template-columns: repeat(3, 1fr);
        }
        
        .action-link {
            color: var(--primary);
            text-decoration: none;
            margin-right: 10px;
            transition: color 0.3s ease;
        }
        
        .action-link:hover {
            color: var(--primary-dark);
        }
        
        .action-link.danger {
            color: var(--danger);
        }
        
        .action-link.danger:hover {
            color: #d61a6f;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 50px;
            margin-bottom: 15px;
            color: var(--light-gray);
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        @media (max-width: 768px) {
            .grid-cols-2, .grid-cols-3 {
                grid-template-columns: 1fr;
            }
            
            .table th, .table td {
                padding: 8px 10px;
            }
            
            .nav-menu {
                flex-direction: column;
            }
        }
    </style>
    <script>
        function calculateTotalValue() {
            const size = parseFloat(document.getElementById('property_size').value) || 0;
            const pricePerUnit = parseFloat(document.getElementById('estimated_price_per_unit').value) || 0;
            const totalValue = size * pricePerUnit;
            document.getElementById('total_value').value = totalValue.toFixed(2);
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="dashboard-header">
            <h1 id="dashboard-title">Seller Dashboard</h1>
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <div class="nav-header" id="header-nav">
            <ul class="nav-menu">
                <li>
                    <a href="seller_dashboard.php" class="active">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </a>
                </li>
                <li>
                    <a href="investment_analytics.php">
                        <i class="fas fa-chart-line"></i>
                        <span>Analytics</span>
                    </a>
                </li>
                <li>
                    <a href="dashboard.php">
                        <i class="fas fa-arrow-left"></i>
                        <span>Main Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">List a New Property</h2>
                <a href="investment_analytics.php" class="btn btn-outline"><i class="fas fa-chart-line"></i> View Analytics</a>
            </div>
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="grid grid-cols-3">
                    <div class="form-group">
                        <label class="form-label">Property Type:</label>
                        <select name="property_type" class="form-control" required>
                            <option value="plot">Plot</option>
                            <option value="flat">Flat</option>
                            <option value="villa">Villa</option>
                            <option value="farm_land">Farm Land</option>
                            <option value="farm_house">Farm House</option>
                            <option value="barren_land">Barren Land</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Size:</label>
                        <input type="number" name="property_size" id="property_size" step="0.01" class="form-control" required oninput="calculateTotalValue()">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Size Unit:</label>
                        <select name="size_unit" class="form-control">
                            <option value="sqm">Square Meters</option>
                            <option value="sqyd">Square Yards</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Ownership Status:</label>
                        <select name="ownership_status" class="form-control" required>
                            <option value="sole">Sole Ownership</option>
                            <option value="co_owned">Co-Owned</option>
                            <option value="mortgaged">Under Mortgage</option>
                            <option value="leased">Leased/Occupied</option>
                            <option value="pending_transfer">Pending Transfer</option>
                            <option value="disputed">Disputed</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Price per Unit:</label>
                        <input type="number" name="estimated_price_per_unit" id="estimated_price_per_unit" step="0.01" class="form-control" required oninput="calculateTotalValue()">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Total Value:</label>
                        <input type="number" name="total_value" id="total_value" step="0.01" class="form-control" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Future Value (optional):</label>
                        <input type="number" name="future_value" step="0.01" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Seller Type:</label>
                        <select name="seller_type" class="form-control" required>
                            <option value="owner">Owner</option>
                            <option value="third_party">Third Party</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" name="negotiation" id="negotiation">
                            <label for="negotiation" class="form-label">Negotiation</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" name="brokering" id="brokering">
                            <label for="brokering" class="form-label">Brokering</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Location:</label>
                        <input type="text" name="location" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">City:</label>
                        <input type="text" name="city" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Usage Type:</label>
                        <select name="usage_type" class="form-control" required>
                            <option value="sale">Sale</option>
                            <option value="rent">Rent</option>
                            <option value="lease">Lease</option>
                            <option value="development">Development</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Features:</label>
                        <textarea name="features" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Description:</label>
                        <textarea name="description" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Property Image URL (optional):</label>
                        <input type="text" name="image_url" class="form-control" placeholder="Enter image URL">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">List Property</button>
            </form>
        </div>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Your Listed Properties</h2>
            </div>
            <?php if (!empty($listed_properties)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type</th>
                                <th>Size</th>
                                <th>Ownership Status</th>
                                <th>Location</th>
                                <th>City</th>
                                <th>Total Value</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($listed_properties as $property): ?>
                                <tr>
                                    <td><?php echo $property['property_id']; ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $property['property_type'])); ?></td>
                                    <td><?php echo $property['property_size'] . ' ' . $property['size_unit']; ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $property['ownership_status'])); ?></td>
                                    <td><?php echo $property['location']; ?></td>
                                    <td><?php echo $property['city']; ?></td>
                                    <td>$<?php echo number_format($property['total_value'], 2); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $property['status'] == 'available' ? 'badge-success' : 'badge-warning'; ?>">
                                            <?php echo ucfirst($property['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($property['status'] == 'available'): ?>
                                            <a href="edit_property.php?id=<?php echo $property['property_id']; ?>" class="action-link">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <a href="seller_dashboard.php?delete_id=<?php echo $property['property_id']; ?>" 
                                               onclick="return confirm('Are you sure you want to delete this property?');" 
                                               class="action-link danger">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-home"></i>
                    <p>You have not listed any properties yet.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Pending Buyer Requests</h2>
            </div>
            <?php if (!empty($pending_requests)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Property ID</th>
                                <th>Type</th>
                                <th>Size</th>
                                <th>Location</th>
                                <th>City</th>
                                <th>Total Value</th>
                                <th>Buyer Username</th>
                                <th>Buyer Contact</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pending_requests as $request): ?>
                                <tr>
                                    <td><?php echo $request['property_id']; ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $request['property_type'])); ?></td>
                                    <td><?php echo $request['property_size'] . ' ' . $request['size_unit']; ?></td>
                                    <td><?php echo $request['location']; ?></td>
                                    <td><?php echo $request['city']; ?></td>
                                    <td>$<?php echo number_format($request['total_value'], 2); ?></td>
                                    <td><?php echo $request['buyer_username']; ?></td>
                                    <td><?php echo $request['buyer_contact']; ?></td>
                                    <td>
                                        <a href="confirm_purchase.php?transaction_id=<?php echo $request['transaction_id']; ?>" 
                                           onclick="return confirm('Confirm this purchase?');" 
                                           class="btn btn-success btn-sm">
                                            <i class="fas fa-check"></i> Confirm
                                        </a>
                                        <a href="chat.php?property_id=<?php echo urlencode($request['property_id']); ?>&receiver_id=<?php echo urlencode($request['buyer_id']); ?>" 
                                           class="action-link">
                                            <i class="fas fa-comments"></i> Chat
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>No pending buyer requests.</p>
                </div>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Messages</h2>
            </div>
            <?php if (!empty($conversations)): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Property ID</th>
                                <th>Property Type</th>
                                <th>City</th>
                                <th>Buyer Username</th>
                                <th>Last Message</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($conversations as $conversation): ?>
                                <?php
                                // Fetch the buyer's user_id for this conversation
                                $sql = "SELECT DISTINCT sender_id FROM messages 
                                        WHERE property_id = :property_id AND sender_id != :seller_id 
                                        LIMIT 1";
                                $stmt = $pdo->prepare($sql);
                                $stmt->execute([
                                    ':property_id' => $conversation['property_id'],
                                    ':seller_id' => $_SESSION['user_id']
                                ]);
                                $buyer_id = $stmt->fetchColumn();
                                ?>
                                <tr>
                                    <td><?php echo $conversation['property_id']; ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $conversation['property_type'])); ?></td>
                                    <td><?php echo $conversation['city']; ?></td>
                                    <td><?php echo $conversation['buyer_username']; ?></td>
                                    <td><?php echo $conversation['last_message']; ?></td>
                                    <td>
                                        <a href="chat.php?property_id=<?php echo urlencode($conversation['property_id']); ?>&receiver_id=<?php echo urlencode($buyer_id); ?>" 
                                           class="action-link">
                                            <i class="fas fa-comments"></i> View & Reply
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-envelope"></i>
                    <p>No messages yet.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <a href="dashboard.php" class="btn btn-primary" style="display: block; text-align: center; margin-top: 20px;">
            <i class="fas fa-arrow-left"></i> Back to Main Dashboard
        </a>
    </div>
</body>
</html>