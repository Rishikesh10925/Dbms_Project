<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['request_id'])) {
    header("Location: index.php");
    exit();
}

$request_id = filter_input(INPUT_GET, 'request_id', FILTER_SANITIZE_NUMBER_INT);
$agent_id = $_SESSION['user_id'];

if (!$request_id) {
    header("Location: agent_dashboard.php?action=development");
    exit();
}

// Verify the request belongs to this agent
$sql = "SELECT * FROM development_requests WHERE request_id = :request_id AND agent_id = :agent_id AND status = 'pending'";
$stmt = $pdo->prepare($sql);
$stmt->execute([':request_id' => $request_id, ':agent_id' => $agent_id]);
$request = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$request) {
    header("Location: agent_dashboard.php?action=development&error=" . urlencode("Invalid request or unauthorized access."));
    exit();
}

try {
    $sql = "UPDATE development_requests SET status = 'confirmed' WHERE request_id = :request_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':request_id' => $request_id]);
    
    header("Location: agent_dashboard.php?action=development&success=" . urlencode("Development request confirmed successfully."));
    exit();
} catch (PDOException $e) {
    header("Location: agent_dashboard.php?action=development&error=" . urlencode("Error confirming request: " . $e->getMessage()));
    exit();
}
?>