<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['property_id']) || !isset($_GET['receiver_id'])) {
    header("Location: index.php");
    exit();
}

$property_id = $_GET['property_id'];
$user_id = $_SESSION['user_id'];
$receiver_id = $_GET['receiver_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $message = $_POST['message'];
        $sql = "INSERT INTO messages (sender_id, receiver_id, property_id, message) 
                VALUES (:sender_id, :receiver_id, :property_id, :message)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':sender_id' => $user_id,
            ':receiver_id' => $receiver_id,
            ':property_id' => $property_id,
            ':message' => $message
        ]);
        $success = "Message sent!";
    } catch (PDOException $e) {
        $error = "Error sending message: " . $e->getMessage();
    }
}

$sql = "SELECT m.*, u.username 
        FROM messages m 
        JOIN users u ON m.sender_id = u.user_id 
        WHERE m.property_id = :property_id 
        AND ((m.sender_id = :user_id AND m.receiver_id = :receiver_id) 
             OR (m.sender_id = :receiver_id AND m.receiver_id = :user_id)) 
        ORDER BY m.sent_at ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':property_id' => $property_id,
    ':user_id' => $user_id,
    ':receiver_id' => $receiver_id
]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>REMA - Chat</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .chat-box { max-height: 400px; overflow-y: auto; border: 1px solid #ccc; padding: 10px; }
        .message { margin: 5px 0; }
        .sent { text-align: right; color: blue; }
        .received { text-align: left; color: green; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Chat for Property #<?php echo $property_id; ?></h1>
        <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        <div class="chat-box">
            <?php foreach ($messages as $msg): ?>
                <div class="message <?php echo $msg['sender_id'] == $user_id ? 'sent' : 'received'; ?>">
                    <strong><?php echo $msg['username']; ?>:</strong> <?php echo htmlspecialchars($msg['message']); ?>
                    <small>(<?php echo $msg['sent_at']; ?>)</small>
                </div>
            <?php endforeach; ?>
        </div>
        <form method="POST">
            <textarea name="message" required placeholder="Type your message"></textarea>
            <button type="submit">Send</button>
        </form>
        <a href="buyer_dashboard.php">Back</a>
    </div>
</body>
</html>