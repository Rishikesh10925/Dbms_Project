<?php
require 'config.php';

$sql = "INSERT INTO market_trends (city, property_type, avg_price, trend_date)
        SELECT p.city, p.property_type, AVG(p.total_value), CURDATE()
        FROM properties p
        WHERE p.status = 'sold'
        GROUP BY p.city, p.property_type";
$stmt = $pdo->prepare($sql);
$stmt->execute();
echo "Market trends updated!";
?>