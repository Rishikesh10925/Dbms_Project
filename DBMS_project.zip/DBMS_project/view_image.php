<?php
session_start();
require 'config.php';

$property_id = $_GET['id'];
$sql = "SELECT image_url FROM properties WHERE property_id = :property_id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':property_id' => $property_id]);
$property = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>REMA - View Property Image</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Property Image</h1>
        <?php if ($property['image_url']): ?>
            <img src="<?php echo $property['image_url']; ?>" alt="Property Image" style="max-width: 800px;">
        <?php else: ?>
            <p>No image available.</p>
        <?php endif; ?>
        <a href="buyer_dashboard.php">Back</a>
    </div>
</body>
</html>