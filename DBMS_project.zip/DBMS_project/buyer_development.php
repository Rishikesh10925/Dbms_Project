<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$buyer_id = $_SESSION['user_id'];
$preselected_property_id = filter_input(INPUT_GET, 'property_id', FILTER_SANITIZE_NUMBER_INT);

// Fetch confirmed purchases that can be developed
$sql = "SELECT p.*, t.transaction_id 
        FROM transactions t 
        JOIN properties p ON t.property_id = p.property_id 
        WHERE t.buyer_id = :buyer_id AND t.status = 'confirmed' 
        AND p.property_id NOT IN (SELECT property_id FROM development_requests WHERE buyer_id = :buyer_id2)";
$stmt = $pdo->prepare($sql);
$stmt->execute([':buyer_id' => $buyer_id, ':buyer_id2' => $buyer_id]);
$properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch development services
$sql = "SELECT * FROM development_services";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle development request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $property_id = filter_input(INPUT_POST, 'property_id', FILTER_SANITIZE_NUMBER_INT);
        $service_id = filter_input(INPUT_POST, 'service_id', FILTER_SANITIZE_NUMBER_INT);
        
        if (!$property_id || !$service_id) {
            throw new Exception("Invalid property or service selection.");
        }

        // Get random agent for this service
        $sql = "SELECT u.user_id 
                FROM users u 
                JOIN agent_services a ON u.user_id = a.agent_id 
                WHERE a.service_id = :service_id 
                ORDER BY RAND() LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':service_id' => $service_id]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($agent) {
            $sql = "INSERT INTO development_requests (property_id, buyer_id, agent_id, service_id, status) 
                    VALUES (:property_id, :buyer_id, :agent_id, :service_id, 'pending')";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':property_id' => $property_id,
                ':buyer_id' => $buyer_id,
                ':agent_id' => $agent['user_id'],
                ':service_id' => $service_id
            ]);
            $success = "Development request sent to agent successfully!";
        } else {
            $error = "No agents available for this service.";
        }
    } catch (Exception $e) {
        $error = "Error submitting request: " . $e->getMessage();
    }
}

// Fetch buyer's development requests
$sql = "SELECT dr.*, p.property_type, p.city, ds.service_name, u.username AS agent_name 
        FROM development_requests dr
        JOIN properties p ON dr.property_id = p.property_id
        JOIN development_services ds ON dr.service_id = ds.service_id
        JOIN users u ON dr.agent_id = u.user_id
        WHERE dr.buyer_id = :buyer_id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':buyer_id' => $buyer_id]);
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>REMA - Buyer Development</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Development Requests</h1>
        <?php if (isset($success)) echo "<p class='success'>" . htmlspecialchars($success) . "</p>"; ?>
        <?php if (isset($error)) echo "<p class='error'>" . htmlspecialchars($error) . "</p>"; ?>
        
        <h2>Request Development for Your Property</h2>
        <?php if (!empty($properties)): ?>
            <form method="POST">
                <label>Select Property:</label>
                <select name="property_id" required>
                    <?php foreach ($properties as $property): ?>
                        <option value="<?php echo htmlspecialchars($property['property_id']); ?>"
                            <?php if ($preselected_property_id == $property['property_id']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($property['property_type'] . ' in ' . $property['city'] . ' (ID: ' . $property['property_id'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <label>Select Service:</label>
                <select name="service_id" required>
                    <?php foreach ($services as $service): ?>
                        <option value="<?php echo htmlspecialchars($service['service_id']); ?>">
                            <?php echo htmlspecialchars($service['service_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <button type="submit">Request Development</button>
            </form>
        <?php else: ?>
            <p>No properties available for development or all properties already have development requests.</p>
        <?php endif; ?>
        
        <h2>Your Development Requests</h2>
        <?php if (!empty($requests)): ?>
            <table>
                <tr>
                    <th>Property ID</th>
                    <th>Type</th>
                    <th>City</th>
                    <th>Service</th>
                    <th>Agent</th>
                    <th>Status</th>
                </tr>
                <?php foreach ($requests as $request): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($request['property_id']); ?></td>
                        <td><?php echo htmlspecialchars($request['property_type']); ?></td>
                        <td><?php echo htmlspecialchars($request['city']); ?></td>
                        <td><?php echo htmlspecialchars($request['service_name']); ?></td>
                        <td><?php echo htmlspecialchars($request['agent_name']); ?></td>
                        <td><?php echo ucfirst(htmlspecialchars($request['status'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>You have no development requests yet.</p>
        <?php endif; ?>
        
        <a href="buyer_dashboard.php">Back to Buyer Dashboard</a>
    </div>
</body>
</html>