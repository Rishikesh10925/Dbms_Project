<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['property_id'])) {
    header("Location: buyer_dashboard.php?error=" . urlencode("Access denied or invalid request."));
    exit();
}

$buyer_id = $_SESSION['user_id'];
$property_id = filter_input(INPUT_GET, 'property_id', FILTER_SANITIZE_NUMBER_INT);

if (!$property_id) {
    header("Location: buyer_dashboard.php?error=" . urlencode("Invalid property ID."));
    exit();
}

// Fetch development request details for the property
$sql = "SELECT dr.*, p.property_type, p.city, ds.service_name, u.username AS agent_name 
        FROM development_requests dr
        JOIN properties p ON dr.property_id = p.property_id
        JOIN development_services ds ON dr.service_id = ds.service_id
        JOIN users u ON dr.agent_id = u.user_id
        WHERE dr.property_id = :property_id AND dr.buyer_id = :buyer_id AND dr.status = 'confirmed'";
$stmt = $pdo->prepare($sql);
$stmt->execute([':property_id' => $property_id, ':buyer_id' => $buyer_id]);
$development = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$development) {
    header("Location: buyer_dashboard.php?error=" . urlencode("No confirmed development request found for this property."));
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>REMA - View Development</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Development Details</h1>
        <p><strong>Property ID:</strong> <?php echo htmlspecialchars($development['property_id']); ?></p>
        <p><strong>Property Type:</strong> <?php echo htmlspecialchars($development['property_type']); ?></p>
        <p><strong>City:</strong> <?php echo htmlspecialchars($development['city']); ?></p>
        <p><strong>Service:</strong> <?php echo htmlspecialchars($development['service_name']); ?></p>
        <p><strong>Agent:</strong> <?php echo htmlspecialchars($development['agent_name']); ?></p>
        <p><strong>Status:</strong> <?php echo ucfirst(htmlspecialchars($development['status'])); ?></p>
        <p><strong>Request Date:</strong> <?php echo htmlspecialchars($development['request_date'] ?? 'N/A'); ?></p>
        <p><strong>Confirmation Date:</strong> <?php echo htmlspecialchars($development['confirmation_date'] ?? 'N/A'); ?></p>
        
        <?php if (isset($_GET['error'])) {
            echo "<p class='error'>" . htmlspecialchars($_GET['error']) . "</p>";
        } ?>
        
        <a href="buyer_dashboard.php">Back to Buyer Dashboard</a>
    </div>
</body>
</html>