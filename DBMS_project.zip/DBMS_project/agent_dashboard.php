<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$action = isset($_GET['action']) ? $_GET['action'] : 'home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>REMA - Agent Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a56d4;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
            --info: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fb;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .dashboard-header h1 {
            color: var(--primary);
            font-weight: 600;
            font-size: 28px;
            margin: 0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .nav-header {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            overflow: hidden;
        }
        
        .nav-menu {
            display: flex;
            list-style: none;
        }
        
        .nav-menu li {
            flex: 1;
        }
        
        .nav-menu a {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 15px 10px;
            color: var(--gray);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }
        
        .nav-menu a:hover, .nav-menu a.active {
            background-color: rgba(67, 97, 238, 0.1);
            color: var(--primary);
        }
        
        .nav-menu i {
            font-size: 18px;
            margin-bottom: 5px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .card-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--dark);
            margin: 0;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 14px;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
        }
        
        .btn-success {
            background-color: var(--success);
            color: white;
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 13px;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        .table th {
            background-color: var(--primary);
            color: white;
            padding: 12px 15px;
            text-align: left;
            font-weight: 500;
        }
        
        .table td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--light-gray);
            vertical-align: middle;
        }
        
        .table tr:last-child td {
            border-bottom: none;
        }
        
        .table tr:hover {
            background-color: rgba(67, 97, 238, 0.05);
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
        }
        
        .badge-warning {
            background-color: rgba(248, 150, 30, 0.1);
            color: var(--warning);
        }
        
        .badge-danger {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--light-gray);
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
        }
        
        .checkbox-group input {
            margin-right: 10px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-success {
            background-color: rgba(76, 201, 240, 0.1);
            color: var(--success);
            border-left: 4px solid var(--success);
        }
        
        .alert-danger {
            background-color: rgba(247, 37, 133, 0.1);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }
        
        .grid {
            display: grid;
            gap: 20px;
        }
        
        .grid-cols-2 {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .action-link {
            color: var(--primary);
            text-decoration: none;
            margin-right: 10px;
            transition: color 0.3s ease;
        }
        
        .action-link:hover {
            color: var(--primary-dark);
        }
        
        .action-link.danger {
            color: var(--danger);
        }
        
        .action-link.danger:hover {
            color: #d61a6f;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 50px;
            margin-bottom: 15px;
            color: var(--light-gray);
        }
        
        @media (max-width: 768px) {
            .nav-menu {
                flex-direction: column;
            }
            
            .grid-cols-2 {
                grid-template-columns: 1fr;
            }
            
            .table th, .table td {
                padding: 8px 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-header">
            <h1 id="dashboard-title">Agent Dashboard</h1>
            <div class="user-info">
                <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <div class="nav-header" id="header-nav">
            <ul class="nav-menu">
                <li>
                    <a href="agent_dashboard.php?action=home" class="<?php echo $action == 'home' ? 'active' : ''; ?>">
                        <i class="fas fa-home"></i>
                        <span>Home</span>
                    </a>
                </li>
                <li>
                    <a href="agent_dashboard.php?action=development" class="<?php echo $action == 'development' ? 'active' : ''; ?>">
                        <i class="fas fa-hammer"></i>
                        <span>Development</span>
                    </a>
                </li>
                <li>
                    <a href="agent_dashboard.php?action=buy" class="<?php echo $action == 'buy' ? 'active' : ''; ?>">
                        <i class="fas fa-shopping-cart"></i>
                        <span>Buy Properties</span>
                    </a>
                </li>
                <li>
                    <a href="agent_dashboard.php?action=sell" class="<?php echo $action == 'sell' ? 'active' : ''; ?>">
                        <i class="fas fa-tag"></i>
                        <span>Sell Properties</span>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>
        </div>

        <?php switch ($action) {
            case 'development': ?>
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Development Services</h2>
                    </div>
                    
                    <h3>Add New Service</h3>
                    <form method="POST" action="add_development_service.php" class="grid grid-cols-2">
                        <div class="form-group">
                            <label class="form-label">Service Name:</label>
                            <input type="text" name="service_name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Description:</label>
                            <textarea name="description" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Add Service</button>
                        </div>
                    </form>
                    
                    <h3>Your Services</h3>
                    <?php
                    $sql = "SELECT ds.* FROM development_services ds 
                            JOIN agent_services a ON ds.service_id = a.service_id 
                            WHERE a.agent_id = :agent_id";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([':agent_id' => $_SESSION['user_id']]);
                    $agent_services = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (!empty($agent_services)): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Service Name</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($agent_services as $service): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($service['service_name']); ?></td>
                                            <td><?php echo htmlspecialchars($service['description']); ?></td>
                                            <td>
                                                <a href="remove_development_service.php?service_id=<?php echo urlencode($service['service_id']); ?>" class="action-link danger">Remove</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-box-open"></i>
                            <p>You haven't added any development services yet.</p>
                        </div>
                    <?php endif; ?>
                    
                    <h3>Development Requests</h3>
                    <?php
                    $sql = "SELECT dr.*, p.property_type, p.city, ds.service_name, u.username AS buyer_name 
                            FROM development_requests dr
                            JOIN properties p ON dr.property_id = p.property_id
                            JOIN development_services ds ON dr.service_id = ds.service_id
                            JOIN users u ON dr.buyer_id = u.user_id
                            WHERE dr.agent_id = :agent_id";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([':agent_id' => $_SESSION['user_id']]);
                    $dev_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (!empty($dev_requests)): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Property ID</th>
                                        <th>Type</th>
                                        <th>City</th>
                                        <th>Service</th>
                                        <th>Buyer</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($dev_requests as $request): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($request['property_id']); ?></td>
                                            <td><?php echo htmlspecialchars($request['property_type']); ?></td>
                                            <td><?php echo htmlspecialchars($request['city']); ?></td>
                                            <td><?php echo htmlspecialchars($request['service_name']); ?></td>
                                            <td><?php echo htmlspecialchars($request['buyer_name']); ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $request['status'] == 'pending' ? 'badge-warning' : 'badge-success'; ?>">
                                                    <?php echo ucfirst(htmlspecialchars($request['status'])); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($request['status'] == 'pending'): ?>
                                                    <a href="confirm_development.php?request_id=<?php echo urlencode($request['request_id']); ?>" class="action-link">Confirm</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <p>You have no development requests yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php break;
            case 'buy': ?>
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Buy Properties</h2>
                    </div>
                    
                    <?php if (isset($_GET['success'])): ?>
                        <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($_GET['error'])): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></div>
                    <?php endif; ?>
                    
                    <?php
                    $sql = "SELECT * FROM properties WHERE status = 'available'";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute();
                    $available_properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (!empty($available_properties)): ?>
                        <form method="POST" action="agent_buy.php">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Select</th>
                                            <th>ID</th>
                                            <th>Type</th>
                                            <th>City</th>
                                            <th>Location</th>
                                            <th>Total Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($available_properties as $property): ?>
                                            <tr>
                                                <td><input type="checkbox" name="property_ids[]" value="<?php echo htmlspecialchars($property['property_id']); ?>"></td>
                                                <td><?php echo htmlspecialchars($property['property_id']); ?></td>
                                                <td><?php echo htmlspecialchars($property['property_type']); ?></td>
                                                <td><?php echo htmlspecialchars($property['city']); ?></td>
                                                <td><?php echo htmlspecialchars($property['location']); ?></td>
                                                <td>$<?php echo number_format(htmlspecialchars($property['total_value']), 2); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="form-group checkbox-group">
                                <input type="checkbox" name="third_party" id="third_party">
                                <label for="third_party">Third Party Purchase</label>
                            </div>
                            <button type="submit" class="btn btn-primary">Buy Selected Properties</button>
                        </form>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-search"></i>
                            <p>No available properties found for purchase.</p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php break;
            case 'sell': ?>
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Sell Properties</h2>
                    </div>
                    
                    <?php if (isset($_GET['success'])): ?>
                        <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($_GET['error'])): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></div>
                    <?php endif; ?>
                    
                    <?php
                    $sql = "SELECT * FROM properties WHERE user_id = :agent_id AND status = 'available'";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([':agent_id' => $_SESSION['user_id']]);
                    $agent_properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (!empty($agent_properties)): ?>
                        <form method="POST" action="agent_bulk_sell.php">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Select</th>
                                            <th>ID</th>
                                            <th>Type</th>
                                            <th>City</th>
                                            <th>Location</th>
                                            <th>Total Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($agent_properties as $property): ?>
                                            <tr>
                                                <td><input type="checkbox" name="property_ids[]" value="<?php echo htmlspecialchars($property['property_id']); ?>"></td>
                                                <td><?php echo htmlspecialchars($property['property_id']); ?></td>
                                                <td><?php echo htmlspecialchars($property['property_type']); ?></td>
                                                <td><?php echo htmlspecialchars($property['city']); ?></td>
                                                <td><?php echo htmlspecialchars($property['location']); ?></td>
                                                <td>$<?php echo number_format(htmlspecialchars($property['total_value']), 2); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <button type="submit" class="btn btn-primary">Sell Selected Properties</button>
                        </form>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-home"></i>
                            <p>You have no available properties to sell.</p>
                        </div>
                    <?php endif; ?>
                </div>
                <?php break;
            case 'home':
            default: ?>
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Welcome to your Agent Dashboard</h2>
                    </div>
                    <div class="card-body">
                        <p>Here you can manage your development services, buy properties, and sell properties on behalf of clients.</p>
                        <div class="grid grid-cols-2" style="margin-top: 30px;">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Quick Actions</h3>
                                </div>
                                <div class="card-body">
                                    <a href="agent_dashboard.php?action=development" class="btn btn-primary" style="display: block; margin-bottom: 10px;">
                                        <i class="fas fa-hammer"></i> Manage Development Services
                                    </a>
                                    <a href="agent_dashboard.php?action=buy" class="btn btn-primary" style="display: block; margin-bottom: 10px;">
                                        <i class="fas fa-shopping-cart"></i> Buy Properties
                                    </a>
                                    <a href="agent_dashboard.php?action=sell" class="btn btn-primary" style="display: block;">
                                        <i class="fas fa-tag"></i> Sell Properties
                                    </a>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Recent Activity</h3>
                                </div>
                                <div class="card-body">
                                    <p>No recent activity to display.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php break;
        } ?>
    </div>
</body>
</html>