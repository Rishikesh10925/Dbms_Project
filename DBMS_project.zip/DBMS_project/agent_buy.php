<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['property_ids'])) {
    header("Location: agent_dashboard.php?action=buy&error=" . urlencode("No properties selected or session expired."));
    exit();
}

$agent_id = $_SESSION['user_id'];
$property_ids = $_POST['property_ids'];
$third_party = isset($_POST['third_party']) ? 1 : 0;

if (!is_array($property_ids) || empty($property_ids)) {
    header("Location: agent_dashboard.php?action=buy&error=" . urlencode("No valid properties selected."));
    exit();
}

try {
    $pdo->beginTransaction();
    $success_count = 0;

    foreach ($property_ids as $property_id) {
        $property_id = filter_var($property_id, FILTER_SANITIZE_NUMBER_INT);
        if (!$property_id) continue;

        $sql = "SELECT * FROM properties WHERE property_id = :property_id AND status = 'available'";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':property_id' => $property_id]);
        if ($stmt->fetch(PDO::FETCH_ASSOC)) {
            $sql = "INSERT INTO transactions (property_id, agent_id, transaction_type, status, is_third_party) 
                    VALUES (:property_id, :agent_id, 'sale', 'pending', :third_party)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':property_id' => $property_id,
                ':agent_id' => $agent_id,
                ':third_party' => $third_party
            ]);

            $sql = "UPDATE properties SET status = 'pending' WHERE property_id = :property_id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':property_id' => $property_id]);
            $success_count++;
        }
    }

    $pdo->commit();
    header("Location: agent_dashboard.php?action=buy&success=" . urlencode("Bulk purchase request submitted successfully for $success_count properties!"));
    exit();
} catch (PDOException $e) {
    $pdo->rollBack();
    header("Location: agent_dashboard.php?action=buy&error=" . urlencode("Error processing bulk purchase: " . $e->getMessage()));
    exit();
}
?>